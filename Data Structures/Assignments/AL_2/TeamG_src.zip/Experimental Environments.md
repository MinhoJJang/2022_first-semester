# Experimental Environments

# MinhoJang

## OS

OS: Linux(ubuntu 20.04.4 LTS)

## CPU

CPU model name: 11th Gen Intel(R) Core(TM) i3-1115G4 @ 3.00GHz
CPU core: 4

## Memory

Memory: 8GB (4GB ram \* 2)
Memory Speed: 2933 MT/s
Memory Type: DDR4
