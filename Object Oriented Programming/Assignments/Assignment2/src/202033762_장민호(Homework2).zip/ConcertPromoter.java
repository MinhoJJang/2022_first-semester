package as2;

public class ConcertPromoter {

	private String nameOfTheBand;
	private int capacityOfTheVenue;
	private int numberOfTicketsSold;
	private double priceOfPhone;
	private double priceOfVenue;
	private double totalSale;
	private int ticketsOnPhone;
	private int ticketsOnVenue;

	public String getNameOfTheBand() {
		return nameOfTheBand;
	}

	public void setNameOfTheBand(String nameOfTheBand) {
		this.nameOfTheBand = nameOfTheBand;
	}

	public int getCapacityOfTheVenue() {
		return capacityOfTheVenue;
	}

	public void setCapacityOfTheVenue(int capacityOfTheVenue) {
		this.capacityOfTheVenue = capacityOfTheVenue;
	}

	public int getNumberOfTicketsSold() {
		return numberOfTicketsSold;
	}

	public void setNumberOfTicketsSold(int numberOfTicketsSold) {
		this.numberOfTicketsSold = numberOfTicketsSold;
	}

	public double getPriceOfPhone() {
		return priceOfPhone;
	}

	public void setPriceOfPhone(double priceOfPhone) {
		this.priceOfPhone = priceOfPhone;
	}

	public double getPriceOfVenue() {
		return priceOfVenue;
	}

	public void setPriceOfVenue(double priceOfVenue) {
		this.priceOfVenue = priceOfVenue;
	}

	public double getTotalSale() {
		return totalSale;
	}

	public void setTotalSale(double totalSale) {
		this.totalSale = totalSale;
	}

	public int getTicketsOnPhone() {
		return ticketsOnPhone;
	}

	public void setTicketsOnPhone(int ticketsOnPhone) {
		this.ticketsOnPhone = ticketsOnPhone;
	}

	public int getTicketsOnVenue() {
		return ticketsOnVenue;
	}

	public void setTicketsOnVenue(int ticketsOnVenue) {
		this.ticketsOnVenue = ticketsOnVenue;
	}
	
	
	
	
	
}
